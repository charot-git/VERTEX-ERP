create definer = vosSystem@`%` trigger update_last_restock_date
    before update
    on inventory
    for each row
BEGIN
    IF NEW.quantity > OLD.quantity THEN
        SET NEW.last_restock_date = NOW();
    END IF;
END;

