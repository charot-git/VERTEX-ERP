create definer = vosSystem@`%` trigger update_payment_status_on_lead_time_payment
    before update
    on purchase_order
    for each row
BEGIN
    IF NEW.lead_time_payment IS NOT NULL 
       AND NEW.lead_time_payment < CURDATE() 
       AND NEW.payment_status NOT IN (4, 7) THEN
        SET NEW.payment_status = 5;
    END IF;
END;

